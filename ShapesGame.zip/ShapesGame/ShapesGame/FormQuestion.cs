﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShapesGame
{
    public partial class frmQuestion : Form
    {
        int CurrentQuestion, CorrectAnswers;
        public frmQuestion()
        {
            InitializeComponent();

            CurrentQuestion = 0;
            CorrectAnswers = 0;
        }
        public void ViewQuestion()
        {
            lblQuestionNumber.Text = string.Format("Q:{0}/{1}", CurrentQuestion + 1, Program.QuestionsShapes.Count);
            DrawShape();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveAnswer();
            if (++CurrentQuestion >= Program.QuestionsShapes.Count)
            {//All questions are completed => viewresult
                frmFormEnd End_Form = new frmFormEnd(CorrectAnswers);
                End_Form.Show();
                this.Hide();
            }
            else
                ViewQuestion();
        }

        private void SaveAnswer()
        {
            foreach (RadioButton rbtnShape in gbxAnswers.Controls)
            {
                if (rbtnShape.Checked)
                {
                    Program.AnswersShapes.Add(rbtnShape.Tag.ToString());
                    if (rbtnShape.Tag.ToString().Equals(Program.QuestionsShapes[CurrentQuestion]))
                        CorrectAnswers++;
                    break;
                }
            }
        }


        private void frmQuestion_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void frmQuestion_Load(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            DrawShape();
        }

        private void DrawShape()
        {
            Graphics g = pbxQuestionShape.CreateGraphics();
            //g.Clear(pbxQuestionShape.BackColor);
            pbxQuestionShape.Refresh();
            switch (Program.QuestionsShapes[CurrentQuestion])
            {
                case "s"://Draw Squara
                    g.FillRectangle(Brushes.Gray, 80, 20, 50 + trackBar1.Value, 50 + trackBar1.Value);

                    break;

                case "r"://Draw Rectangle
                    g.FillRectangle(Brushes.Green, 20, 10, 100 + trackBar1.Value, 50 + trackBar1.Value);
                    break;

                case "c"://Draw Circle
                    g.FillEllipse(Brushes.Azure, 50, 20, 50 + trackBar1.Value, 50 + trackBar1.Value);
                    break;

                case "t"://Draw Triangle
                    Point[] points = { new Point(pbxQuestionShape.Width/2, 10), new Point(pbxQuestionShape.Width / 2-50- trackBar1.Value, 60 + trackBar1.Value), new Point(pbxQuestionShape.Width / 2+50+ trackBar1.Value, 60+ trackBar1.Value), new Point(pbxQuestionShape.Width / 2, 10) };
                    g.DrawLines(Pens.OrangeRed, points);
                    break;
            }
        }
    }
}
