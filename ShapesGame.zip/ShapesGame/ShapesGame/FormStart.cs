﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShapesGame
{
    public partial class frmFormStart : Form
    {
        public frmFormStart()
        {
            InitializeComponent();
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                panel1.Visible = true;
                txtFileName.Text = openFileDialog1.FileName;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Program.QuestionsShapes.Clear();
            StreamReader reader = new StreamReader(txtFileName.Text);

            string CurrentShape = string.Empty;
            while (!reader.EndOfStream)
            {
                CurrentShape = reader.ReadLine().ToLower();
                if (Program.ShapesList.IndexOf(CurrentShape) > -1)
                {
                    Program.QuestionsShapes.Add(CurrentShape);
                }
            }
            reader.Close();
            if (Program.QuestionsShapes.Count == 0)
            {
                MessageBox.Show("The file has no shape symboles (s,r,c,t)...!!!", "No Shapes Exist", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (MessageBox.Show(string.Format("The file has {0} valid shape symbols.\r\nStart test?", Program.QuestionsShapes.Count), "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                frmQuestion Q_Form = new frmQuestion();

                Q_Form.Show();
                this.Hide();
                Q_Form.ViewQuestion();
            }
        }

        private void frmFormStart_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
