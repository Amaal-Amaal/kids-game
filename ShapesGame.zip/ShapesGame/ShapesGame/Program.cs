﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShapesGame
{
    static class Program
    {
        public static List<string> QuestionsShapes = new List<string>();
        public static List<string> AnswersShapes = new List<string>();
        public static List<string> ShapesList = new List<string>() { "s", "r", "c", "t" };
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmFormStart());
        }
    }
}
