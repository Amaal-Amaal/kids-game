﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ShapesGame
{
    public partial class frmFormEnd : Form
    {
        int CorrectAnswers;
        public frmFormEnd(int CorrectAnswers)
        {
            this.CorrectAnswers = CorrectAnswers;
            InitializeComponent();
        }

        private void frmFormEnd_Load(object sender, EventArgs e)
        {
            DataTable dtQA = new DataTable();
            dtQA.Columns.Add("Question");
            dtQA.Columns.Add("Answer");
            dtQA.Columns.Add("Correctness");
            for (int i = 0; i < Program.QuestionsShapes.Count; i++)
            {
                DataRow dr = dtQA.NewRow();
                dr[0] = GetShapeName(Program.QuestionsShapes[i]);
                dr[1] = GetShapeName(Program.AnswersShapes[i]);
                dr[2] = Program.QuestionsShapes[i].ToString().Equals(Program.AnswersShapes[i]).ToString();
                dtQA.Rows.Add(dr);
            }
            gridQuestions.DataSource = dtQA;
        }

        private object GetShapeName(string ShapeName)
        {
            switch (ShapeName)
            {
                case "s": return "Square";
                case "r": return "Rectangle";
                case "c": return "Circle";
                case "t": return "Triangle";
            }
            return string.Empty;
        }

        private void frmFormEnd_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void frmFormEnd_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                bool pass = this.CorrectAnswers >= Program.QuestionsShapes.Count / 2;
                Graphics g = this.CreateGraphics();

                g.DrawString(string.Format("You score\r\n\t{0} out of {1}", this.CorrectAnswers, Program.QuestionsShapes.Count),
                  new Font(FontFamily.GenericSerif, 15, FontStyle.Bold),
                  pass ? Brushes.Green : Brushes.Red, 10, 10);

                pbxPass.Visible = pass;
                pbxFail.Visible = !pass;
            }
            catch
            {
                MessageBox.Show("Wrong number format !!!");
            }
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            frmFormStart StartForm = new frmFormStart();
            StartForm.Show();
            this.Hide();
        }
    }
}
