﻿
namespace ShapesGame
{
    partial class frmQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbxQuestionShape = new System.Windows.Forms.PictureBox();
            this.gbxAnswers = new System.Windows.Forms.GroupBox();
            this.rbtnTriangle = new System.Windows.Forms.RadioButton();
            this.rbtnRectangle = new System.Windows.Forms.RadioButton();
            this.rbtnCircle = new System.Windows.Forms.RadioButton();
            this.rbtnSquare = new System.Windows.Forms.RadioButton();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblQuestionNumber = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.pbxQuestionShape)).BeginInit();
            this.gbxAnswers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxQuestionShape
            // 
            this.pbxQuestionShape.Location = new System.Drawing.Point(14, 61);
            this.pbxQuestionShape.Name = "pbxQuestionShape";
            this.pbxQuestionShape.Size = new System.Drawing.Size(513, 333);
            this.pbxQuestionShape.TabIndex = 0;
            this.pbxQuestionShape.TabStop = false;
            // 
            // gbxAnswers
            // 
            this.gbxAnswers.Controls.Add(this.rbtnTriangle);
            this.gbxAnswers.Controls.Add(this.rbtnRectangle);
            this.gbxAnswers.Controls.Add(this.rbtnCircle);
            this.gbxAnswers.Controls.Add(this.rbtnSquare);
            this.gbxAnswers.Location = new System.Drawing.Point(26, 397);
            this.gbxAnswers.Name = "gbxAnswers";
            this.gbxAnswers.Size = new System.Drawing.Size(472, 57);
            this.gbxAnswers.TabIndex = 1;
            this.gbxAnswers.TabStop = false;
            this.gbxAnswers.Text = "Answer";
            // 
            // rbtnTriangle
            // 
            this.rbtnTriangle.AutoSize = true;
            this.rbtnTriangle.Location = new System.Drawing.Point(381, 23);
            this.rbtnTriangle.Name = "rbtnTriangle";
            this.rbtnTriangle.Size = new System.Drawing.Size(76, 21);
            this.rbtnTriangle.TabIndex = 5;
            this.rbtnTriangle.Tag = "t";
            this.rbtnTriangle.Text = "Triangle";
            this.rbtnTriangle.UseVisualStyleBackColor = true;
            // 
            // rbtnRectangle
            // 
            this.rbtnRectangle.AutoSize = true;
            this.rbtnRectangle.Location = new System.Drawing.Point(253, 23);
            this.rbtnRectangle.Name = "rbtnRectangle";
            this.rbtnRectangle.Size = new System.Drawing.Size(89, 21);
            this.rbtnRectangle.TabIndex = 4;
            this.rbtnRectangle.Tag = "r";
            this.rbtnRectangle.Text = "Rectangle";
            this.rbtnRectangle.UseVisualStyleBackColor = true;
            // 
            // rbtnCircle
            // 
            this.rbtnCircle.AutoSize = true;
            this.rbtnCircle.Location = new System.Drawing.Point(132, 23);
            this.rbtnCircle.Name = "rbtnCircle";
            this.rbtnCircle.Size = new System.Drawing.Size(61, 21);
            this.rbtnCircle.TabIndex = 3;
            this.rbtnCircle.Tag = "c";
            this.rbtnCircle.Text = "Circle";
            this.rbtnCircle.UseVisualStyleBackColor = true;
            // 
            // rbtnSquare
            // 
            this.rbtnSquare.AutoSize = true;
            this.rbtnSquare.Checked = true;
            this.rbtnSquare.Location = new System.Drawing.Point(16, 23);
            this.rbtnSquare.Name = "rbtnSquare";
            this.rbtnSquare.Size = new System.Drawing.Size(72, 21);
            this.rbtnSquare.TabIndex = 2;
            this.rbtnSquare.TabStop = true;
            this.rbtnSquare.Tag = "s";
            this.rbtnSquare.Text = "Square";
            this.rbtnSquare.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location = new System.Drawing.Point(445, 462);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 39);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblQuestionNumber
            // 
            this.lblQuestionNumber.AutoSize = true;
            this.lblQuestionNumber.Location = new System.Drawing.Point(12, 18);
            this.lblQuestionNumber.Name = "lblQuestionNumber";
            this.lblQuestionNumber.Size = new System.Drawing.Size(42, 17);
            this.lblQuestionNumber.TabIndex = 3;
            this.lblQuestionNumber.Text = "label1";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(100, -1);
            this.trackBar1.Maximum = 200;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(373, 56);
            this.trackBar1.TabIndex = 4;
            this.trackBar1.TickFrequency = 20;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // frmQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 507);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.lblQuestionNumber);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gbxAnswers);
            this.Controls.Add(this.pbxQuestionShape);
            this.MaximizeBox = false;
            this.Name = "frmQuestion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Question";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmQuestion_FormClosed);
            this.Load += new System.EventHandler(this.frmQuestion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxQuestionShape)).EndInit();
            this.gbxAnswers.ResumeLayout(false);
            this.gbxAnswers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxQuestionShape;
        private System.Windows.Forms.GroupBox gbxAnswers;
        private System.Windows.Forms.RadioButton rbtnTriangle;
        private System.Windows.Forms.RadioButton rbtnRectangle;
        private System.Windows.Forms.RadioButton rbtnCircle;
        private System.Windows.Forms.RadioButton rbtnSquare;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblQuestionNumber;
        private System.Windows.Forms.TrackBar trackBar1;
    }
}

