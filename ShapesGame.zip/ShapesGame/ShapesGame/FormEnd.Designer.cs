﻿
namespace ShapesGame
{
    partial class frmFormEnd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFormEnd));
            this.pbxPass = new System.Windows.Forms.PictureBox();
            this.pbxFail = new System.Windows.Forms.PictureBox();
            this.gridQuestions = new System.Windows.Forms.DataGridView();
            this.btnRestart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridQuestions)).BeginInit();
            this.SuspendLayout();
            // 
            // pbxPass
            // 
            this.pbxPass.Image = ((System.Drawing.Image)(resources.GetObject("pbxPass.Image")));
            this.pbxPass.Location = new System.Drawing.Point(12, 138);
            this.pbxPass.Name = "pbxPass";
            this.pbxPass.Size = new System.Drawing.Size(219, 180);
            this.pbxPass.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxPass.TabIndex = 1;
            this.pbxPass.TabStop = false;
            // 
            // pbxFail
            // 
            this.pbxFail.Image = ((System.Drawing.Image)(resources.GetObject("pbxFail.Image")));
            this.pbxFail.Location = new System.Drawing.Point(21, 138);
            this.pbxFail.Name = "pbxFail";
            this.pbxFail.Size = new System.Drawing.Size(201, 180);
            this.pbxFail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxFail.TabIndex = 2;
            this.pbxFail.TabStop = false;
            // 
            // gridQuestions
            // 
            this.gridQuestions.AllowUserToAddRows = false;
            this.gridQuestions.AllowUserToDeleteRows = false;
            this.gridQuestions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridQuestions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridQuestions.Location = new System.Drawing.Point(237, 12);
            this.gridQuestions.Name = "gridQuestions";
            this.gridQuestions.ReadOnly = true;
            this.gridQuestions.RowHeadersWidth = 51;
            this.gridQuestions.RowTemplate.Height = 26;
            this.gridQuestions.Size = new System.Drawing.Size(327, 284);
            this.gridQuestions.TabIndex = 3;
            // 
            // btnRestart
            // 
            this.btnRestart.BackColor = System.Drawing.Color.YellowGreen;
            this.btnRestart.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.btnRestart.Location = new System.Drawing.Point(468, 302);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(87, 29);
            this.btnRestart.TabIndex = 4;
            this.btnRestart.Text = "RESTART";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // frmFormEnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(567, 335);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.gridQuestions);
            this.Controls.Add(this.pbxFail);
            this.Controls.Add(this.pbxPass);
            this.MinimizeBox = false;
            this.Name = "frmFormEnd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Result Form";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmFormEnd_FormClosed);
            this.Load += new System.EventHandler(this.frmFormEnd_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmFormEnd_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.pbxPass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridQuestions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pbxPass;
        private System.Windows.Forms.PictureBox pbxFail;
        private System.Windows.Forms.DataGridView gridQuestions;
        private System.Windows.Forms.Button btnRestart;
    }
}